//
//  HomeVC.m
//  futures
//
//  Created by Ssiswent on 2020/5/11.
//  Copyright © 2020 Francis. All rights reserved.
//

#import "HomeVC.h"

@interface HomeVC ()

@end

@implementation HomeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置导航栏背景图片为一个空的image，这样就透明了
    [self.navigationController.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
    //去掉透明后导航栏下边的黑边
    [self.navigationController.navigationBar setShadowImage:[[UIImage alloc] init]];
    self.navigationController.navigationBar.translucent = YES;
    
    self.navigationController.navigationBar.backgroundColor = [UIColor colorWithRed:254/255.0 green:162/255.0 blue:3/255.0 alpha:1.0];
    NSLog(@"%@", NSStringFromCGRect(self.navigationController.navigationBar.frame));
    
    //导航栏搜索框
    UITextField *searchView = [[UITextField alloc] init];
    searchView.frame = CGRectMake(15.5,9,300,27);
    searchView.backgroundColor = [UIColor colorWithRed:254/255.0 green:247/255.0 blue:231/255.0 alpha:1.0];
        //设置边角弧度
    searchView.layer.cornerRadius = 12;
    searchView.placeholder = @"数字货币";
    
    [self.navigationController.navigationBar addSubview:searchView];
    
    //导航栏右边签到图片
    UIImageView *qiandaoImage = [[UIImageView alloc]init];
    qiandaoImage.frame = CGRectMake(340.5, 12.5, 19.5, 20.5);
    qiandaoImage.image = [UIImage imageNamed:@"ic_qiandao"];
    
    [self.navigationController.navigationBar addSubview:qiandaoImage];
    
    
    
    CGFloat bannerW = 345;
    CGFloat bannerH = 190;
    CGFloat bannerRimW = 9;
    CGFloat bannerViewW = [UIScreen mainScreen].bounds.size.width;
    CGFloat bannerSpaceW = ([UIScreen mainScreen].bounds.size.width - bannerW - 2 * bannerRimW)/2;
    NSLog(@"%d",(int)bannerSpaceW);
    
    //轮播图
    UIScrollView *bannerScrollView = [[UIScrollView alloc]init];
    bannerScrollView.frame = CGRectMake(0, 57, bannerViewW, bannerH);
    bannerScrollView.backgroundColor = [UIColor whiteColor];
    
        //添加轮播图图片
    int bannerCount = 3;
    for(int i=0; i<bannerCount; i++){
        UIImageView *bannerImageView = [[UIImageView alloc] init];
        bannerImageView.image = [UIImage imageNamed:@"banner01_home"];
        bannerImageView.frame = CGRectMake(i * (bannerW + bannerSpaceW), 0, bannerW + bannerSpaceW, bannerH);
        [bannerScrollView addSubview:bannerImageView];
        NSLog(@"%d",(int) bannerScrollView.contentSize.width);
    }
    
    bannerScrollView.contentSize = CGSizeMake(bannerCount * (bannerW + bannerSpaceW), 0);
    NSLog(@"%d", (int) bannerScrollView.contentSize.width);
    NSLog(@"%d", (int) bannerScrollView.frame.size.width);
    
    bannerScrollView.pagingEnabled = YES;
    bannerScrollView.scrollEnabled = YES;
    
    [self.navigationController.navigationBar addSubview:bannerScrollView];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
